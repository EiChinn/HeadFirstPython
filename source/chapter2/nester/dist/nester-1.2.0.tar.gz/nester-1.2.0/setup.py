from distutils.core import setup

setup(
    name = 'nester',
    version = '1.2.0',
    py_modules = ['nester'],
    author = 'eichinn',
    author_email = 'eichinn77@gmail.com',
    url = 'www.eichinn.com',
    description = 'A simple printer of nested list',
    )
